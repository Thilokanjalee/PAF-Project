package org.electro_grid.com;

import org.electro_grid.model.*;

//For REST Service
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

//For JSON
import com.google.gson.*;

//For XML
import org.jsoup.*;
import org.jsoup.parser.*;
import org.jsoup.nodes.Document;

@Path("/Billing")
public class BillingService {

	Billing billObj = new Billing();
	
	@GET
	@Path("/{accNo}")
	@Produces(MediaType.TEXT_HTML)
	public String readBilling(@PathParam("accNo") String accNo)
	{
		System.out.println(accNo);
		
		return billObj.readBillingDetails(accNo);
	}
	
}

